<?php

namespace app\common\controller;


/**
 * Class MongoClientUtils
 * @package app\common\controller
 *
 * mogondb操作工具类
 */

class MongoClientUtils
{
    static  $instance = null;

    public static function getInstance() {

        $mongonArray = config('mongo');
        if (is_null(self::$instance)) {
            self::$instance =   new \MongoDB\Driver\Manager("mongodb://{$mongonArray['mongo_host']}:{$mongonArray['mongo_port']}",array(
                'username' => $mongonArray['mongo_user'],
                'password' => $mongonArray['mongo_password']
            ));
        }
        return self::$instance;
    }
}