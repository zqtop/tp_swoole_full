<?php
namespace app\controller;

use app\BaseController;
use think\App;
use think\facade\Db;
use think\Request;
use think\Response;

class Index extends BaseController
{
    protected  $request;


    public function __construct(Request $request)
    {
       $this->request = $request;

    }

    public function index()
    {
        echo \think\facade\Route::buildUrl();
    }




    public function  test()
    {
        $start_time = $this->microtime_float();
        $swoole_mysql = new \Swoole\Coroutine\MySQL();
        $swoole_mysql->connect([
            'host' => '192.168.169.138',
            'port' => 3306,
            'user' => 'root',
            'password' => 'root',
            "charset" => "utf8",
            'database' => 'swoole',
        ]);
        $swoole_mysql->query('select * from sw_user limit 10000');
        $end_time = $this->microtime_float();
        var_dump($end_time-$start_time);
    }

    function microtime_float()
    {
        list($usec, $sec) = explode(" ", microtime());
        return ((float)$usec + (float)$sec);
    }


    public  function  demo()
    {
        $start_time = $this->microtime_float();
        $res = Db::name("user")->limit(10000)->select();
        $end_time = $this->microtime_float();
        var_dump($res);
        var_dump($end_time-$start_time);
    }

    public function  request()
    {
           return json(["code"=>200,"msg"=>"success"],200);
    }

}
