<?php
namespace app\controller;
use app\BaseController;
use app\common\controller\MongoClientUtils;
use think\facade\View;

/**
 * Created by PhpStorm.
 * User: php
 * Date: 2021/4/4
 * Time: 9:56
 */
class Movie  extends BaseController{


    /**
     * @return string
     * @throws \MongoDB\Driver\Exception\Exception
     * @Route("movie/movie/index")
     */
    public function index()
    {
        $manager = MongoClientUtils::getInstance();
        $filter = [];
        $options = [
            'limit' => 1000
        ];
// 查询数据
        $query = new \MongoDB\Driver\Query($filter, $options);
        $cursor = $manager->executeQuery('douban.yellow_movie', $query);
        $arrayInfo = [];
        if ($cursor) {
            foreach ($cursor as $document) {
                $tmp = [];
                $tmp ['movie_name'] = $document->movie_name;
                $tmp ['down_load_url'] = $document->down_load_url;
                $arrayInfo[]= $tmp;
            }
        }

        return View::fetch('movie', [
            'data'  => $arrayInfo
        ]);
    }

}