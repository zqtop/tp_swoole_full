<?php
/**
 * Created by PhpStorm.
 * User: php
 * Date: 2021/4/4
 * Time: 9:59
 */

return [
    'mongo_host' => '192.168.1.138',
    'mongo_port' =>  27017,
    'mongo_db' => 'douban',
    'mongo_collection' => 'yellow_movie',
    'mongo_user' => 'douban',
    'mongo_password' => '123456'
];